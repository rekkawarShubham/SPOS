#include<stdio.h>
#include<unistd.h>

int main()
{
  printf("This is executed by exec.c\n");
  return 0;
}
